package com.netrix.security

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast

class InAppBrowserActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        val w = findViewById<WebView>(R.id.webView)
        val url = intent.getStringExtra("url") ?: ""
        // Quick re-check before loading
        val verdict = Scanner.scanText(this, url)
        if (verdict.isThreat) {
            Toast.makeText(this, "Blocked unsafe URL", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        w.webViewClient = WebViewClient()
        w.settings.javaScriptEnabled = true
        w.loadUrl(url)
    }
}
