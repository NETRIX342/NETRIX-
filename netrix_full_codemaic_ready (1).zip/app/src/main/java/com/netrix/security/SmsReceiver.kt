package com.netrix.security

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (m in msgs) {
                val from = m.originatingAddress ?: "unknown"
                val body = m.messageBody ?: ""
                val verdict = Scanner.scanText(context, body)
                if (verdict.isThreat) {
                    // store and notify
                    ReportStore.addReport(context, verdict.message, "SMS from $from: $body")
                    NotificationHelper.showThreatNotification(context, "Blocked SMS", verdict.message)
                    // abortBroadcast() historically used but system may handle delivery differently
                }
            }
        } catch (e: Exception) {
            Log.e("SmsReceiver", "err", e)
        }
    }
}
