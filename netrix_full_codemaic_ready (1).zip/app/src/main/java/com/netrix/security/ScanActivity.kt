package com.netrix.security

import android.content.Intent
import android.os.Bundle
import android.webkit.URLUtil
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat

class ScanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)
        val input = findViewById<EditText>(R.id.inputText)
        val result = findViewById<TextView>(R.id.resultText)
        val checkBtn = findViewById<Button>(R.id.checkBtn)
        checkBtn.setOnClickListener {
            val text = input.text.toString()
            val verdict = Scanner.scanText(this, text)
            result.text = verdict.message
            result.setTextColor(ContextCompat.getColor(this, verdict.colorRes))
            if (verdict.isThreat) {
                // Save to report DB
                ReportStore.addReport(this, verdict.message, text)
                NotificationHelper.showThreatNotification(this, "Threat detected", verdict.message)
            }
            // If it's a URL and safe, open in app browser
            if (!verdict.isThreat && URLUtil.isNetworkUrl(text)) {
                val i = Intent(this, InAppBrowserActivity::class.java)
                i.putExtra("url", text)
                startActivity(i)
            }
        }
    }
}
