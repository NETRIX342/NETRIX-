package com.netrix.security

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class ReportsAdapter(private val data: JSONArray): RecyclerView.Adapter<ReportsAdapter.VH>() {
    class VH(v: View): RecyclerView.ViewHolder(v) {
        val t1: TextView = v.findViewById(R.id.rTitle)
        val t2: TextView = v.findViewById(R.id.rDetails)
        val t3: TextView = v.findViewById(R.id.rTime)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_report, parent, false)
        return VH(v)
    }
    override fun getItemCount(): Int = data.length()
    override fun onBindViewHolder(holder: VH, position: Int) {
        val obj = data.getJSONObject(position)
        holder.t1.text = obj.getString("title")
        holder.t2.text = obj.getString("details")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        holder.t3.text = sdf.format(Date(obj.getLong("time")))
    }
}
