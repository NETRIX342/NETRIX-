package com.netrix.security

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val scanBtn = findViewById<Button>(R.id.btnScan)
        val reportsBtn = findViewById<Button>(R.id.btnReports)
        scanBtn.setOnClickListener {
            startActivity(Intent(this, ScanActivity::class.java))
        }
        reportsBtn.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
        // Simple about dialog
        findViewById<Button>(R.id.btnAbout).setOnClickListener {
            AlertDialog.Builder(this).setTitle("NETRIX")
                .setMessage("NETRIX — Learn, Secure, Evolve\nSMS & Link protection")
                .setPositiveButton("OK", null).show()
        }
    }
}
