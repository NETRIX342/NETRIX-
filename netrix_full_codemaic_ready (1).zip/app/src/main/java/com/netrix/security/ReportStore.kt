package com.netrix.security

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ReportStore {
    private const val PREF = "netrix_reports"
    private const val KEY = "reports"

    fun addReport(ctx: Context, title: String, details: String) {
        val prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val obj = JSONObject()
        obj.put("title", title)
        obj.put("details", details)
        obj.put("time", System.currentTimeMillis())
        arr.put(obj)
        // keep only last 100
        while (arr.length() > 100) arr.remove(0)
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun getReports(ctx: Context): JSONArray {
        val prefs = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        return JSONArray(raw)
    }
}
