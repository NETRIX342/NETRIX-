package com.netrix.security

import android.content.Context
import android.util.Patterns
import androidx.annotation.ColorRes

data class Verdict(val isThreat: Boolean, val message: String, @ColorRes val colorRes: Int)

object Scanner {
    private val dangerousWords = listOf("hack","virus","malware","fraud","lottery","winner","prize","claim")
    private val suspiciousTlds = listOf(".xyz",".top",".icu",".tk")

    fun scanText(context: Context, text: String): Verdict {
        val lower = text.lowercase()
        // quick keyword check
        if (dangerousWords.any { lower.contains(it) }) {
            return Verdict(true, "⚠️ Suspicious keywords found", android.R.color.holo_red_light)
        }
        // url check
        val urls = extractUrls(text)
        if (urls.isNotEmpty()) {
            // local heuristics
            if (urls.any { isSuspiciousUrl(it) }) {
                return Verdict(true, "⚠️ Suspicious link pattern found", android.R.color.holo_red_light)
            }
            // optional remote Safe Browsing check (stub)
            val safe = SafeBrowsingHelper.checkUrlsSync(urls)
            if (!safe) {
                return Verdict(true, "⚠️ Malicious link detected by Safe Browsing", android.R.color.holo_red_light)
            }
            return Verdict(false, "✔️ Link looks safe", android.R.color.holo_green_dark)
        }
        return Verdict(false, "✔️ Safe content", android.R.color.holo_green_dark)
    }

    private fun extractUrls(text: String): List<String> {
        val m = Patterns.WEB_URL.matcher(text)
        val list = mutableListOf<String>()
        while (m.find()) list.add(m.group())
        return list
    }

    private fun isSuspiciousUrl(url: String): Boolean {
        val u = url.lowercase()
        if (suspiciousTlds.any { u.contains(it) }) return true
        if (u.contains("bit.ly")||u.contains("tinyurl")||u.contains("goo.gl")) return true
        if (u.length>200) return true
        return false
    }
}
