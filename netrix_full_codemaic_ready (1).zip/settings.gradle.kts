rootProject.name = "NETRIX"
include(":app")
